import os
import librosa
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow import lite
import tensorflow.keras as keras


def prepare_dataset(dataset_path):
    data_labels = []
    data_MFCC = []
    i = 0

    for (root, dirs, files) in os.walk(dataset_path):
        if root is not dataset_path:
            for f in files:
                file_path = os.path.join(root, f)
                signal, sr = librosa.load(file_path, sr=16000)

                if len(signal) >= 16000:
                    signal = signal[:16000]
                    MFCC = librosa.feature.mfcc(signal, n_mfcc=13, hop_length=512, n_fft=2040)
                    data_labels.append(i)
                    data_MFCC.append(MFCC.T.tolist())
            i += 1
    return data_labels, data_MFCC


def get_data_splits(lab_lst, mfcc_lst):
    X = np.array(mfcc_lst)
    y = np.array(lab_lst)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=1, stratify=y)

    X_train = X_train[..., np.newaxis]
    X_test = X_test[..., np.newaxis]

    return X_train, X_test, y_train, y_test


def build_model():

    model = keras.Sequential()
    model.add(keras.layers.Conv2D(32, kernel_size=(3, 3), padding="same", activation="relu", input_shape=(32,13,1)))
    model.add(keras.layers.MaxPooling2D(pool_size=(2, 2)))

    model.add(keras.layers.Conv2D(64, kernel_size=(3, 3), padding="same", activation="relu"))
    model.add(keras.layers.MaxPooling2D(pool_size=(2, 2)))
    model.add(keras.layers.Dropout(0.25))

    model.add(keras.layers.Conv2D(128, kernel_size=(3, 3), padding="same", activation="relu"))
    model.add(keras.layers.MaxPooling2D(pool_size=(2, 2)))
    model.add(keras.layers.Dropout(0.25))

    model.add(keras.layers.Flatten())

    model.add(keras.layers.Dense(128, activation="relu"))
    model.add(keras.layers.Dense(6, activation="softmax"))

    model.compile(optimizer='adam', loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    model.summary()

    return model


def save_model(model):
    converter = lite.TFLiteConverter.from_keras_model(model)
    TFLite_model = converter.convert()
    open("model.tflite", "wb").write(TFLite_model)


def train(lab_lst, mfcc_lst):
    # generate train and test set
    X_train, X_test, y_train, y_test = get_data_splits(lab_lst, mfcc_lst)

    # Creating CNN
    model = build_model()

    # Start model training
    model.fit(X_train, y_train, epochs=40, batch_size=32)

    # Evaluate the model
    model.evaluate(X_test, y_test)

    # Convert the model in TFLite & save
    save_model(model)


if __name__ == "__main__":
    labels_list, MFCC_list = prepare_dataset("DATASET")
    train(labels_list, MFCC_list)
